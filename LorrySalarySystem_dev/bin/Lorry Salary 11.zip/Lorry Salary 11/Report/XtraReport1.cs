﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace LorrySalarySystem_dev.Report
{
    public partial class XtraReport1 : DevExpress.XtraReports.UI.XtraReport
    {
        
        public XtraReport1()
        {
            InitializeComponent();
            //XtraReport1 report = new XtraReport1();
            //report.ShowPreview();
            //report.CreateDocument();
           // DO_Date_End.Value = DateTime.Now.ToString("dd/mm/yyyy");
        }

    }
}
